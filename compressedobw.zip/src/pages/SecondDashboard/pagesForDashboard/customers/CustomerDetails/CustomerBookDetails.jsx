import React from 'react'

const CustomerBookDetails = () => {
  return (
    <div>
      
    </div>
  )
}

export default CustomerBookDetails

// useledsss
