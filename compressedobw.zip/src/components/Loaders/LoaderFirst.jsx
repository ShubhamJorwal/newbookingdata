import React from 'react'
import './loaderFirst.scss'

const LoaderFirst = () => {
  return (
    <>
      <span id="loading01"></span>
    </>
  )
}

export default LoaderFirst
