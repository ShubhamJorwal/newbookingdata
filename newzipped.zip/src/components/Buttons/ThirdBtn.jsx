import React from "react";

const ThirdBtn = ({ title }) => {
  return (
    <>
      <div id="thirdbtn">{title}</div>
    </>
  );
};

export default ThirdBtn;
