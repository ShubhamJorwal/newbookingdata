import React from 'react'

const FirstBtn = ({title}) => {
  return (
    <>
      <button id="firstbtn">{title}</button>
    </>
  )
}

export default FirstBtn
